<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('isihalaman'); ?>
    

    <div class="card-box pd-20 height-100-p mb-30">
        <div class="">
            
            <div class="">
                <h4 class="font-20 weight-500 mb-10 text-capitalize">
                    Welcome
                    <div class="weight-600 font-30 text-blue"><?php echo e(auth()->user()->nama); ?></div>
                </h4>
                <p class="font-18" align="justify">
                    Selamat datang di website pengaduan masyarakat! Kami senang Anda telah mengunjungi situs kami dan ingin
                    menyampaikan keluhan atau masalah yang Anda hadapi. Kami berharap dengan adanya platform ini, kami dapat
                    membantu Anda menyelesaikan masalah atau setidaknya memberikan solusi yang memuaskan bagi Anda. Kami
                    akan bekerja keras untuk memastikan bahwa setiap pengaduan yang masuk akan ditangani dengan serius dan
                    responsif. Terima kasih atas kepercayaan Anda kepada kami dan jangan ragu untuk menghubungi kami jika
                    ada hal yang ingin Anda sampaikan.
                </p>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/pages/masyarakat-home.blade.php ENDPATH**/ ?>