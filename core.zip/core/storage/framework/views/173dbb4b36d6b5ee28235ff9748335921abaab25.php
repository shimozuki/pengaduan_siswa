<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($title ?? ''); ?> Siswa Peduli</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('vendors/images/sitemap.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('vendors/images/sitemap.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('vendors/images/sitemap.png')); ?>" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/styles/core.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/styles/icon-font.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('src/plugins/datatables/css/dataTables.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('src/plugins/datatables/css/responsive.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href=" <?php echo e(asset('vendors/styles/style.css')); ?> " />

    <style>
        .lds-ellipsis {
            display: inline-block;
            position: relative;
            width: 80px;
            height: 80px;
        }

        .lds-ellipsis div {
            position: absolute;
            top: 33px;
            width: 13px;
            height: 13px;
            border-radius: 50%;
            background: #3473C8;
            animation-timing-function: cubic-bezier(0, 1, 1, 0);
        }

        .lds-ellipsis div:nth-child(1) {
            left: 8px;
            animation: lds-ellipsis1 0.6s infinite;
        }

        .lds-ellipsis div:nth-child(2) {
            left: 8px;
            animation: lds-ellipsis2 0.6s infinite;
        }

        .lds-ellipsis div:nth-child(3) {
            left: 32px;
            animation: lds-ellipsis2 0.6s infinite;
        }

        .lds-ellipsis div:nth-child(4) {
            left: 56px;
            animation: lds-ellipsis3 0.6s infinite;
        }

        @keyframes lds-ellipsis1 {
            0% {
                transform: scale(0);
            }

            100% {
                transform: scale(1);
            }
        }

        @keyframes lds-ellipsis3 {
            0% {
                transform: scale(1);
            }

            100% {
                transform: scale(0);
            }
        }

        @keyframes lds-ellipsis2 {
            0% {
                transform: translate(0, 0);
            }

            100% {
                transform: translate(24px, 0);
            }
        }
    </style>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo">
                <img src="<?php echo e(asset('vendors/images/1.png')); ?>" alt="" width="220px" height="220px"
                    style="margin:0; padding: 0" />
            </div>
            
            
            <div class="lds-ellipsis " style="margin-left:100px; margin-top:0">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <script src=" <?php echo e(asset('src/plugins/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- js -->
    <script src="<?php echo e(asset('vendors/scripts/core.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/script.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/process.js')); ?>"></script>
    
    

    
    <script src="<?php echo e(asset('src/plugins/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
    <!-- buttons for Export datatable -->
    <script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/vfs_fonts.js')); ?>"></script>



    

    <script src="<?php echo e(asset('vendors/scripts/datatable-setting.js')); ?>"></script>

    <script src=" <?php echo e(asset('vendors/scripts/dashboard3.js')); ?>"></script>
    <script src=" <?php echo e(asset('src/plugins/sweetalert2/sweetalert2.all.js')); ?>"></script>
    <script src=" <?php echo e(asset('src/plugins/sweetalert2/sweet-alert.init.js')); ?>"></script>
    <!-- Datatable Setting js -->
    <?php echo $__env->yieldPushContent('custom-scripts'); ?>
</body>

</html>
<?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/index.blade.php ENDPATH**/ ?>