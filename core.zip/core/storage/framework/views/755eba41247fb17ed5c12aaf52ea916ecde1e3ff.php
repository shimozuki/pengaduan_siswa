<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('isihalaman'); ?>
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            <h4>Data Pengaduan <?php echo e($title); ?></h4>
                        </div>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="/">Home</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Data Pengaduan <?php echo e($title); ?>

                                </li>
                            </ol>
                        </nav>
                    </div>
                    
                </div>
            </div>

            <!-- Export Datatable start -->
            <div class="card-box mb-30">
                <div class="pd-20">
                    <h4 class="text-blue h4">Data Pengaduan <?php echo e($title); ?></h4>
                </div>
                <?php if(Auth::guard('petugass')->user()->level == 'admin'): ?>
                    <button id="export-pdf-pengaduan" class="btn btn-primary"
                        style="margin-left: 15px; margin-bottom: 10px">Export to
                        PDF</button>
                <?php endif; ?>
                <div class="pb-20">
                    <table class="table hover data-table-export nowrap" id="myTable">
                        <thead>
                            <tr>
                                <th class="table-plus">Judul Laporan</th>
                                <th class="none">Foto</th>
                                <th class="none">Isi Laporan</th>
                                <th class="none">Nama Pengadu</th>
                                <th class="none">Asal Sekolah</th>
                                <th class="none">Tgl Pengaduan</th>
                                <th class="datatable-nosort notexport all">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-plus"><?php echo e($m->judul_laporan); ?></td>
                                    <td>
                                        <img src="<?php echo e($m->foto); ?>" alt="" class="mb-30 text-center"
                                            height="100px" width="100px" style="  border: 5px solid #555;">
                                    </td>
                                    <td><?php echo e($m->isi_laporan); ?></td>
                                    <td><?php echo e($m->pengadu->nama); ?></td>
                                    <td><?php echo e($m->sekolah); ?></td>
                                    <td><?php echo e($m->tgl_pengaduan); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                                href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                <i class="dw dw-more"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list"
                                                style="">
                                                <a href="#" data-toggle="modal" style="margin-right: 10px"
                                                    class="dropdown-item" data-target="#viewModal<?php echo e($m->id_pengaduan); ?>"
                                                    type="button">
                                                    <i class="dw dw-eye"></i>View
                                                </a>
                                                <?php switch($title):
                                                    case ('Baru'): ?>
                                                        <form action="/pengaduan/verifikasi/<?php echo e($m->id_pengaduan); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="dropdown-item btn-primary btn-block"><i
                                                                    class="icon-copy fa fa-check-circle"
                                                                    aria-hidden="true"></i>Verifikasi</button>
                                                        </form>
                                                    <?php break; ?>

                                                    <?php case ('Terverifikasi'): ?>
                                                        <a href="#" data-toggle="modal" style="margin-right: 10px"
                                                            class="dropdown-item"
                                                            data-target="#tanggapanModal<?php echo e($m->id_pengaduan); ?>" type="button">
                                                            <i class="icon-copy fa fa-comment" aria-hidden="true"></i>Beri
                                                            Tanggapan
                                                        </a>
                                                    <?php break; ?>

                                                    <?php case ('Selesai'): ?>
                                                        <a href="#" data-toggle="modal" style="margin-right: 10px"
                                                            class="dropdown-item"
                                                            data-target="#tanggapanModal<?php echo e($m->id_pengaduan); ?>" type="button">
                                                            <i class="icon-copy fa fa-comment" aria-hidden="true"></i>Lihat
                                                            Tanggapan
                                                        </a>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                <?php endswitch; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                
                                <div class="modal fade bs-example-modal-lg" id="viewModal<?php echo e($m->id_pengaduan); ?>"
                                    tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myLargeModalLabel">
                                                    <?php echo e($m->judul_laporan); ?>

                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">
                                                    ×
                                                </button>
                                            </div>
                                            <div class="modal-body text-center font-18">
                                                <img src="<?php echo e($m->foto); ?>" alt="" class="mb-30 text-center"
                                                    height="200px" width="400px" style="  border: 5px solid #555;">
                                                <p
                                                    style="    white-space: normal;
                                                overflow: auto;
                                                line-break: anywhere;">
                                                    <?php echo e($m->isi_laporan); ?>


                                                </p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="modal fade bs-example-modal-lg" id="tanggapanModal<?php echo e($m->id_pengaduan); ?>"
                                    tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myLargeModalLabel">
                                                    Tanggapan
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">
                                                    ×
                                                </button>
                                            </div>
                                            <?php if($title == 'Selesai'): ?>
                                                <div class="modal-body">
                                                    <div class="form-group row">
                                                        <label class="col-sm-12 col-md-4 col-form-label">Tanggapan</label>
                                                        <div class="col-sm-12 col-md-8">
                                                            <textarea class="form-control" name="tanggapan" cols="30" rows="10" disabled><?php echo e($m->tanggapan->tanggapan); ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">
                                                        Close
                                                    </button>
                                                <?php else: ?>
                                                    <div class="modal-body">
                                                        <form method="POST"
                                                            action="/pengaduan/tanggapan/<?php echo e($m->id_pengaduan); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group row">
                                                                <label
                                                                    class="col-sm-12 col-md-4 col-form-label">Tanggapan</label>
                                                                <div class="col-sm-12 col-md-8">
                                                                    <textarea class="form-control" name="tanggapan" cols="30" rows="10"></textarea>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">
                                                            Close
                                                        </button>
                                                        <button type="submit" class="btn btn-primary">
                                                            Save changes
                                                        </button>
                                                    </div>
                                                    </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div style="visibility:hidden " id="status"><?php echo e($title); ?></div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('index', ['title' => 'Data-Pengaduan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/pages/data-pengaduan.blade.php ENDPATH**/ ?>