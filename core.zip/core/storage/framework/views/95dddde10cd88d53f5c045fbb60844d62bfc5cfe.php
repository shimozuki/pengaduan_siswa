<div class="main-container">
    <?php echo $__env->yieldContent('isihalaman'); ?>
</div>
<?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/content.blade.php ENDPATH**/ ?>