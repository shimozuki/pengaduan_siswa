<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('isihalaman'); ?>
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            <h4>Data Petugas</h4>
                        </div>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="/">Home</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Data Petugas
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right">
                        <button class="btn btn-primary " href="#" role="button" data-target="#addModal"
                            data-toggle="modal">
                            Tambah Data
                        </button>
                    </div>
                </div>
            </div>

            <!-- Export Datatable start -->
            <div class="card-box mb-30">
                <div class="pd-20">
                    <h4 class="text-blue h4">Data Petugas</h4>
                </div>
                <button id="export-pdf-petugas" class="btn btn-primary"
                    style="margin-left: 15px; margin-bottom: 10px">Export to
                    PDF</button>
                <div class="pb-20">
                    <table class="table hover data-table-export nowrap" id="myTable">
                        <thead>
                            <tr>
                                <th class="table-plus">Nama Petugas</th>
                                <th>Username</th>
                                <th>telp</th>
                                <th>level</th>
                                <th class="datatable-nosort notexport">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-plus"><?php echo e($p->nama_petugas); ?></td>
                                    <td><?php echo e($p->username); ?></td>
                                    <td><?php echo e($p->telp); ?></td>
                                    <td><?php echo e($p->level); ?></td>
                                    <td>
                                        <div class="table-actions">
                                            <a href="#" data-color="#265ed7" data-toggle="modal"
                                                style="margin-right: 10px" data-target="#editModal<?php echo e($p->id_petugas); ?>"
                                                type="button">
                                                <i class="icon-copy dw dw-edit2"></i>
                                            </a>
                                            <a href="#" data-color="#e95959"
                                                onclick="saDeleteWarning('<?php echo e($p->id_petugas); ?>')"><i
                                                    class="icon-copy dw dw-delete-3"></i>
                                            </a>

                                            <form action="/admin/petugas/<?php echo e($p->id_petugas); ?>" method="post"
                                                style="visibility:hidden">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="dropdown-item" id="delete<?php echo e($p->id_petugas); ?>"
                                                    type="submit">
                                                </button>
                                            </form>
                                            <?php $__env->startPush('custom-scripts'); ?>
                                                <script>
                                                    function saDeleteWarning(id) {
                                                        swal({
                                                            title: 'Are you sure?',
                                                            text: "You won't be able to revert this!",
                                                            type: 'warning',
                                                            showCancelButton: true,
                                                            confirmButtonText: 'Yes, delete it!',
                                                            cancelButtonText: 'No, cancel!',
                                                            confirmButtonClass: 'btn btn-success margin-5',
                                                            cancelButtonClass: 'btn btn-danger margin-5',
                                                            buttonsStyling: false
                                                        }).then((result) => {
                                                            if (result.value == true) {
                                                                document.getElementById(`delete${id}`).click();
                                                            } else if (result.dismiss === Swal.DismissReason.cancel) {}
                                                        })
                                                    };
                                                </script>
                                            <?php $__env->stopPush(); ?>
                                        </div>

                                    </td>
                                </tr>
                                <!-- Edit Modal -->
                                <div class="modal fade bs-example-modal-lg" id="editModal<?php echo e($p->id_petugas); ?>"
                                    tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myLargeModalLabel">
                                                    Edit Data
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">
                                                    ×
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="POST" action="/admin/petugas/<?php echo e($p->id_petugas); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="form-group row">
                                                        <label class="col-sm-12 col-md-4 col-form-label">Nama
                                                            petugas</label>
                                                        <div class="col-sm-12 col-md-8">
                                                            <input class="form-control" type="text" name="nama_petugas"
                                                                value="<?php echo e($p->nama_petugas); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-12 col-md-4 col-form-label">Username</label>
                                                        <div class="col-sm-12 col-md-8">
                                                            <input class="form-control" type="text" name="username"
                                                                value="<?php echo e($p->username); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-12 col-md-4 col-form-label">Telp</label>
                                                        <div class="col-sm-12 col-md-8">
                                                            <input class="form-control" type="text" name="telp"
                                                                value="<?php echo e($p->telp); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-12 col-md-4 col-form-label">Select</label>
                                                        <div class="col-sm-12 col-md-8">
                                                            <select class="custom-select col-12" name="level">
                                                                <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($p->level == $l): ?>
                                                                        <option value="<?php echo e($l); ?>" selected
                                                                            name="level">
                                                                            <?php echo e($l); ?></option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($l); ?>" name="level">
                                                                            <?php echo e($l); ?></option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                </button>
                                                <button type="submit" class="btn btn-primary">
                                                    Save changes
                                                </button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- add Modal -->
            <div class="modal fade bs-example-modal-lg" id="addModal" tabindex="-1" role="dialog"
                aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">
                                Tambah Data
                            </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="/admin/petugas">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-4 col-form-label">Nama petugas</label>
                                    <div class="col-sm-12 col-md-8">
                                        <input class="form-control" type="text" name="nama_petugas" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-4 col-form-label">Username</label>
                                    <div class="col-sm-12 col-md-8">
                                        <input class="form-control" type="text" name="username" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-4 col-form-label">Password</label>
                                    <div class="col-sm-12 col-md-8">
                                        <input class="form-control" type="text" name="password" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-4 col-form-label">Telp</label>
                                    <div class="col-sm-12 col-md-8">
                                        <input class="form-control" type="text" name="telp" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-4 col-form-label">Select</label>
                                    <div class="col-sm-12 col-md-8">
                                        <select class="custom-select col-12" name="level">
                                            <option value="petugas" name="level">petugas</option>
                                            <option value="admin" name="level">admin</option>
                                        </select>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" class="btn btn-primary">
                                Save changes
                            </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php $__env->startPush('custom-scripts'); ?>
                <script>
                    function saLoginError() {
                        swal({
                            type: 'error',
                            title: 'username yang anda masukan sudah terdaftar!',
                            text: 'harap coba lagi',
                        })
                    };
                </script>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <script>
                        saLoginError()
                    </script>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__env->stopPush(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('index', ['title' => 'Data-Petugas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/pages/data-petugas.blade.php ENDPATH**/ ?>