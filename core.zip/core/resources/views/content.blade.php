<div class="main-container">
    @yield('isihalaman')
</div>
