<div class="header">
    <div class="header-left">
        <div class="menu-icon bi bi-list"></div>
    </div>
    <div class="header-right">
        <?php if(auth()->guard()->check()): ?>
            <div class="user-info-dropdown" style="margin: 13px;text-transform: uppercase;">
                <div class="dropdown">
                    <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                        
                        <span class="user-name"> <?php echo e(Auth::user()->username); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="dropdown-item" type="submit">
                                <i class='dw dw-logout'></i> Logout
                            </button>
                        </form>
                        
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/header.blade.php ENDPATH**/ ?>