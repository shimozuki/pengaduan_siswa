<div class="left-side-bar" style="padding-top: 20px">
    <div class="brand-logo">
        <a href="#">
            
            <img src=" <?php echo e(asset('vendors/images/2.png')); ?>" alt="" class="light-logo"/> 
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>
    <div class="menu-block customscroll" style="padding-top: 20px">
        <div class="sidebar-menu" >
            <?php if(Auth::guard('masyarakats')->check()): ?>
                <ul id="accordion-menu">
                    <li>
                        <a href="<?php echo e(route('masyarakat.home')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon bi bi-house"></span><span class="mtext">Home</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="<?php echo e(route('masyarakat.pengaduan.saya')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon bi bi-clipboard2-data"></span><span class="mtext">Pengaduan Saya</span>
                        </a>
                    </li>
                </ul>
            <?php elseif(Auth::guard('petugass')->check()): ?>
                <ul id="accordion-menu">
                    <li>
                        <a href="<?php echo e(route('home')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon bi bi-house"></span><span class="mtext">Home</span>
                        </a>
                    </li>
                    <?php if(Auth::guard('petugass')->user()->level == 'admin'): ?>
                        <li class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon bi bi-table"></span><span class="mtext">Admin</span>
                            </a>
                            <ul class="submenu">
                                <li><a href="/admin/petugas">Data Petugas</a></li>
                                <li><a href="/admin/masyarakat">Data Siswa</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <li class="dropdown">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon bi bi-clipboard-data"></span><span class="mtext">Pengaduan</span>
                        </a>
                        <ul class="submenu">
                            <li><a href="/pengaduan/baru">Baru</a></li>
                            <li><a href="/pengaduan/terverifikasi">Terverifikasi</a></li>
                            <li><a href="/pengaduan/selesai">Selesai</a></li>
                        </ul>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/shimozuki/Documents/Laravel/laravel_pengaduan_masyarakat/resources/views/left-sidebar.blade.php ENDPATH**/ ?>